/**
 * script.js — Young Boys WordPress Theme
 * Loaded via wp_enqueue_script() in functions.php (in footer).
 * PHP data is available via the `youngboysData` object (wp_localize_script).
 */

document.addEventListener( 'DOMContentLoaded', function () {

  /* ============================================================
     1. NAVBAR — Scroll shadow
     ============================================================ */
  var header = document.getElementById( 'site-header' );

  if ( header ) {
    window.addEventListener( 'scroll', function () {
      header.classList.toggle( 'scrolled', window.scrollY > 10 );
    } );
  }

  /* ============================================================
     2. NAVBAR — Mobile hamburger toggle
     ============================================================ */
  var hamburgerBtn = document.getElementById( 'hamburgerBtn' );
  var primaryNav   = document.getElementById( 'primary-navigation' );

  if ( hamburgerBtn && primaryNav ) {
    hamburgerBtn.addEventListener( 'click', function () {
      var isOpen = primaryNav.classList.toggle( 'open' );
      hamburgerBtn.classList.toggle( 'active', isOpen );
      hamburgerBtn.setAttribute( 'aria-expanded', isOpen );
    } );

    // Close on nav link click (one-page navigation)
    primaryNav.querySelectorAll( 'a' ).forEach( function ( link ) {
      link.addEventListener( 'click', function () {
        primaryNav.classList.remove( 'open' );
        hamburgerBtn.classList.remove( 'active' );
        hamburgerBtn.setAttribute( 'aria-expanded', 'false' );
      } );
    } );
  }

  /* ============================================================
     3. SMOOTH SCROLL — anchor links
     ============================================================ */
  document.querySelectorAll( 'a[href^="#"]' ).forEach( function ( anchor ) {
    anchor.addEventListener( 'click', function ( e ) {
      var targetId = anchor.getAttribute( 'href' );
      var target   = document.querySelector( targetId );
      if ( target ) {
        e.preventDefault();
        target.scrollIntoView( { behavior: 'smooth', block: 'start' } );
      }
    } );
  } );

  /* ============================================================
     4. CONTACT FORM — Client-side validation + AJAX submit
     ============================================================ */
  var contactForm = document.getElementById( 'contactForm' );
  var successBox  = document.getElementById( 'successBox' );

  if ( contactForm ) {

    // Field config: id, validate fn, error message group id
    var fields = [
      {
        input:    contactForm.querySelector( '#contactName' ),
        group:    document.getElementById( 'fg-name' ),
        validate: function ( v ) { return v.trim().length >= 2; },
      },
      {
        input:    contactForm.querySelector( '#contactEmail' ),
        group:    document.getElementById( 'fg-email' ),
        validate: function ( v ) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test( v.trim() ); },
      },
      {
        input:    contactForm.querySelector( '#contactMessage' ),
        group:    document.getElementById( 'fg-message' ),
        validate: function ( v ) { return v.trim().length >= 10; },
      },
    ];

    // Real-time validation on blur
    fields.forEach( function ( field ) {
      if ( ! field.input ) return;

      field.input.addEventListener( 'blur', function () {
        setFieldError( field, ! field.validate( field.input.value ) );
      } );

      field.input.addEventListener( 'input', function () {
        if ( field.group.classList.contains( 'has-error' ) && field.validate( field.input.value ) ) {
          setFieldError( field, false );
        }
      } );
    } );

    // Form submit
    contactForm.addEventListener( 'submit', function ( e ) {
      e.preventDefault();

      // Validate all fields
      var hasError = false;
      fields.forEach( function ( field ) {
        if ( ! field.input ) return;
        var invalid = ! field.validate( field.input.value );
        setFieldError( field, invalid );
        if ( invalid ) hasError = true;
      } );

      if ( hasError ) {
        // Focus first error
        var firstError = contactForm.querySelector( '.form-group.has-error input, .form-group.has-error textarea' );
        if ( firstError ) firstError.focus();
        return;
      }

      // Build FormData for AJAX
      var formData = new FormData();
      formData.append( 'action',          'youngboys_contact' );
      formData.append( 'nonce',           youngboysData.nonce );
      formData.append( 'contact_name',    contactForm.querySelector( '#contactName' ).value );
      formData.append( 'contact_email',   contactForm.querySelector( '#contactEmail' ).value );
      formData.append( 'contact_message', contactForm.querySelector( '#contactMessage' ).value );

      // Disable submit button while sending
      var submitBtn = contactForm.querySelector( '.btn-submit' );
      if ( submitBtn ) {
        submitBtn.disabled    = true;
        submitBtn.textContent = 'Sending…';
      }

      // AJAX request to WordPress admin-ajax.php
      fetch( youngboysData.ajaxUrl, {
        method: 'POST',
        body:   formData,
      } )
        .then( function ( res ) { return res.json(); } )
        .then( function ( data ) {
          if ( data.success ) {
            // Show success box, hide form
            contactForm.style.display = 'none';
            if ( successBox ) {
              successBox.style.display = 'block';
            }
          } else {
            // Server-side field errors
            if ( data.data && data.data.errors ) {
              var errMap = {
                name:    fields[0],
                email:   fields[1],
                message: fields[2],
              };
              Object.keys( data.data.errors ).forEach( function ( key ) {
                if ( errMap[ key ] ) setFieldError( errMap[ key ], true );
              } );
            }
            // Re-enable submit
            if ( submitBtn ) {
              submitBtn.disabled    = false;
              submitBtn.textContent = 'Send Message →';
            }
          }
        } )
        .catch( function ( err ) {
          console.error( 'Contact form error:', err );
          if ( submitBtn ) {
            submitBtn.disabled    = false;
            submitBtn.textContent = 'Send Message →';
          }
        } );
    } );
  }

  /**
   * Helper: toggle error state on a field group.
   * @param {object}  field
   * @param {boolean} hasError
   */
  function setFieldError( field, hasError ) {
    if ( ! field.group ) return;
    field.group.classList.toggle( 'has-error', hasError );
  }

  /* ============================================================
     5. STATS — Animate numbers into view (Intersection Observer)
     ============================================================ */
  var statNumbers = document.querySelectorAll( '.stat-number' );

  if ( 'IntersectionObserver' in window && statNumbers.length ) {
    var statObserver = new IntersectionObserver(
      function ( entries ) {
        entries.forEach( function ( entry ) {
          if ( entry.isIntersecting ) {
            entry.target.style.opacity   = '1';
            entry.target.style.transform = 'translateY(0)';
            statObserver.unobserve( entry.target );
          }
        } );
      },
      { threshold: 0.5 }
    );

    statNumbers.forEach( function ( el ) {
      el.style.opacity   = '0';
      el.style.transform = 'translateY(10px)';
      el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
      statObserver.observe( el );
    } );
  }

  /* ============================================================
     6. PROJECT CARDS — Subtle click feedback
     ============================================================ */
  document.querySelectorAll( '.project-card' ).forEach( function ( card ) {
    card.addEventListener( 'click', function () {
      card.style.transform = 'translateY(-8px) scale(1.01)';
      setTimeout( function () { card.style.transform = ''; }, 300 );
    } );
  } );

} );
